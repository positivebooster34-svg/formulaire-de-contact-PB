from flask import Blueprint

user_bp = Blueprint('user', __name__)

# Ajoutez ici les routes utilisateur si nécessaire, sinon laissez vide.
# Par exemple :
# @user_bp.route('/users', methods=['GET'])
# def get_users():
#     return 'Liste des utilisateurs'

