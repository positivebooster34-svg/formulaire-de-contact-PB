from flask import Blueprint, request, jsonify
from src.models.user import db
from src.models.prospect import Prospect, ProspectLog
import re
import json
from datetime import datetime

prospect_bp = Blueprint('prospect', __name__)

def validate_email(email):
    """Valide le format d'une adresse email"""
    pattern = r'^[^\s@]+@[^\s@]+\.[^\s@]+$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    """Valide le format d'un numéro de téléphone français"""
    # Pattern pour numéros français avec ou sans espaces/tirets
    pattern = r'^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$'
    return re.match(pattern, phone.strip()) is not None

def validate_name(name):
    """Valide un nom ou prénom"""
    if not name or len(name.strip()) < 2 or len(name.strip()) > 50:
        return False
    # Accepte lettres, espaces, tirets et apostrophes
    pattern = r'^[a-zA-ZÀ-ÿ\s\-\']+$'
    return re.match(pattern, name.strip()) is not None

def log_prospect_action(prospect_id, action, details=None, ip_address=None, user_agent=None):
    """Enregistre une action sur un prospect pour la conformité RGPD"""
    try:
        log_entry = ProspectLog(
            prospect_id=prospect_id,
            action=action,
            details=json.dumps(details) if details else None,
            ip_address=ip_address,
            user_agent=user_agent,
            utilisateur='system'  # Ou récupérer l'utilisateur authentifié
        )
        db.session.add(log_entry)
        db.session.commit()
    except Exception as e:
        print(f"Erreur lors de l'enregistrement du log: {e}")

@prospect_bp.route('/prospects', methods=['POST'])
def create_prospect():
    """Endpoint pour créer un nouveau prospect à partir du formulaire"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'message': 'Aucune donnée reçue'
            }), 400
        
        # Validation des champs obligatoires
        required_fields = ['nom', 'prenom', 'tel', 'email', 'preferenceContact', 'consentementRGPD']
        missing_fields = []
        
        for field in required_fields:
            if field not in data or not data[field]:
                missing_fields.append(field)
        
        if missing_fields:
            return jsonify({
                'success': False,
                'message': f'Champs manquants: {", ".join(missing_fields)}'
            }), 400
        
        # Validation du consentement RGPD (obligatoire)
        if not data.get('consentementRGPD'):
            return jsonify({
                'success': False,
                'message': 'Le consentement RGPD est obligatoire'
            }), 400
        
        # Validation des formats
        errors = []
        
        if not validate_name(data['nom']):
            errors.append('Le nom doit contenir entre 2 et 50 caractères et uniquement des lettres')
        
        if not validate_name(data['prenom']):
            errors.append('Le prénom doit contenir entre 2 et 50 caractères et uniquement des lettres')
        
        if not validate_phone(data['tel']):
            errors.append('Le numéro de téléphone n\'est pas valide')
        
        if not validate_email(data['email']):
            errors.append('L\'adresse email n\'est pas valide')
        
        if len(data['email']) > 100:
            errors.append('L\'adresse email ne peut pas dépasser 100 caractères')
        
        if data['preferenceContact'] not in ['mail', 'tel']:
            errors.append('La préférence de contact doit être "mail" ou "tel"')
        
        if errors:
            return jsonify({
                'success': False,
                'message': 'Erreurs de validation',
                'errors': errors
            }), 400
        
        # Vérifier si l'email existe déjà
        existing_prospect = Prospect.query.filter_by(email=data['email']).first()
        if existing_prospect:
            return jsonify({
                'success': False,
                'message': 'Un prospect avec cette adresse email existe déjà'
            }), 409
        
        # Créer le nouveau prospect
        prospect = Prospect(
            nom=data['nom'].strip(),
            prenom=data['prenom'].strip(),
            telephone=data['tel'].strip(),
            email=data['email'].strip().lower(),
            preference_contact=data['preferenceContact'],
            tranche_horaire=data.get('trancheHoraire'),
            consentement_rgpd=bool(data['consentementRGPD']),
            consentement_marketing=bool(data.get('consentementMarketing', False)),
            ip_address=request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr),
            user_agent=request.headers.get('User-Agent')
        )
        
        # Traiter les jours de préférence (si contact téléphonique)
        if data['preferenceContact'] == 'tel' and 'joursPreference' in data:
            jours_valides = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi']
            jours_selectionnes = []
            
            if isinstance(data['joursPreference'], list):
                for jour in data['joursPreference']:
                    if jour in jours_valides:
                        jours_selectionnes.append(jour)
            
            prospect.set_jours_preference(jours_selectionnes)
        
        # Sauvegarder en base
        db.session.add(prospect)
        db.session.commit()
        
        # Enregistrer l'action dans les logs
        log_prospect_action(
            prospect.id,
            'creation',
            {
                'preference_contact': prospect.preference_contact,
                'consentement_marketing': prospect.consentement_marketing
            },
            prospect.ip_address,
            prospect.user_agent
        )
        
        return jsonify({
            'success': True,
            'message': 'Prospect créé avec succès',
            'prospect_id': prospect.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Erreur lors de la création du prospect: {e}")
        return jsonify({
            'success': False,
            'message': 'Erreur interne du serveur'
        }), 500

@prospect_bp.route('/prospects', methods=['GET'])
def get_prospects():
    """Endpoint pour récupérer la liste des prospects (avec pagination)"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        statut = request.args.get('statut')
        
        # Limiter le nombre d'éléments par page
        per_page = min(per_page, 100)
        
        query = Prospect.query
        
        if statut:
            query = query.filter_by(statut=statut)
        
        prospects = query.order_by(Prospect.date_creation.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'success': True,
            'prospects': [prospect.to_dict() for prospect in prospects.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': prospects.total,
                'pages': prospects.pages,
                'has_next': prospects.has_next,
                'has_prev': prospects.has_prev
            }
        })
        
    except Exception as e:
        print(f"Erreur lors de la récupération des prospects: {e}")
        return jsonify({
            'success': False,
            'message': 'Erreur interne du serveur'
        }), 500

@prospect_bp.route('/prospects/<int:prospect_id>', methods=['GET'])
def get_prospect(prospect_id):
    """Endpoint pour récupérer un prospect spécifique"""
    try:
        prospect = Prospect.query.get(prospect_id)
        
        if not prospect:
            return jsonify({
                'success': False,
                'message': 'Prospect non trouvé'
            }), 404
        
        # Enregistrer la consultation
        log_prospect_action(
            prospect.id,
            'consultation',
            ip_address=request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr),
            user_agent=request.headers.get('User-Agent')
        )
        
        return jsonify({
            'success': True,
            'prospect': prospect.to_dict()
        })
        
    except Exception as e:
        print(f"Erreur lors de la récupération du prospect: {e}")
        return jsonify({
            'success': False,
            'message': 'Erreur interne du serveur'
        }), 500

@prospect_bp.route('/prospects/<int:prospect_id>', methods=['PUT'])
def update_prospect(prospect_id):
    """Endpoint pour mettre à jour un prospect"""
    try:
        prospect = Prospect.query.get(prospect_id)
        
        if not prospect:
            return jsonify({
                'success': False,
                'message': 'Prospect non trouvé'
            }), 404
        
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'message': 'Aucune donnée reçue'
            }), 400
        
        # Sauvegarder les anciennes valeurs pour les logs
        old_values = prospect.to_dict()
        
        # Mettre à jour les champs autorisés
        updatable_fields = ['statut', 'tranche_horaire']
        updated_fields = []
        
        for field in updatable_fields:
            if field in data:
                setattr(prospect, field, data[field])
                updated_fields.append(field)
        
        if updated_fields:
            prospect.date_modification = datetime.utcnow()
            db.session.commit()
            
            # Enregistrer la modification
            log_prospect_action(
                prospect.id,
                'modification',
                {
                    'champs_modifies': updated_fields,
                    'anciennes_valeurs': {field: old_values[field] for field in updated_fields}
                },
                request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr),
                request.headers.get('User-Agent')
            )
            
            return jsonify({
                'success': True,
                'message': 'Prospect mis à jour avec succès',
                'prospect': prospect.to_dict()
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Aucun champ à mettre à jour'
            }), 400
            
    except Exception as e:
        db.session.rollback()
        print(f"Erreur lors de la mise à jour du prospect: {e}")
        return jsonify({
            'success': False,
            'message': 'Erreur interne du serveur'
        }), 500

@prospect_bp.route('/prospects/<int:prospect_id>', methods=['DELETE'])
def delete_prospect(prospect_id):
    """Endpoint pour supprimer un prospect (conformité RGPD)"""
    try:
        prospect = Prospect.query.get(prospect_id)
        
        if not prospect:
            return jsonify({
                'success': False,
                'message': 'Prospect non trouvé'
            }), 404
        
        # Enregistrer la suppression avant de supprimer
        log_prospect_action(
            prospect.id,
            'suppression',
            {'raison': 'Demande de suppression RGPD'},
            request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr),
            request.headers.get('User-Agent')
        )
        
        # Supprimer le prospect
        db.session.delete(prospect)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Prospect supprimé avec succès'
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"Erreur lors de la suppression du prospect: {e}")
        return jsonify({
            'success': False,
            'message': 'Erreur interne du serveur'
        }), 500

@prospect_bp.route('/prospects/<int:prospect_id>/logs', methods=['GET'])
def get_prospect_logs(prospect_id):
    """Endpoint pour récupérer l'historique des actions sur un prospect"""
    try:
        prospect = Prospect.query.get(prospect_id)
        
        if not prospect:
            return jsonify({
                'success': False,
                'message': 'Prospect non trouvé'
            }), 404
        
        logs = ProspectLog.query.filter_by(prospect_id=prospect_id)\
                               .order_by(ProspectLog.date_action.desc())\
                               .all()
        
        return jsonify({
            'success': True,
            'logs': [log.to_dict() for log in logs]
        })
        
    except Exception as e:
        print(f"Erreur lors de la récupération des logs: {e}")
        return jsonify({
            'success': False,
            'message': 'Erreur interne du serveur'
        }), 500

